#' @keywords internal
#' @noRd
`%||%` <- function(a, b) if (is.null(a)) b else a
